//
// Created by kevin on 4/10/19.
//

#ifndef TECFLIX_MOVIE_H
#define TECFLIX_MOVIE_H
#include <string>
#include <cstring>
#include <string>

using namespace std;


class movie {
public:
    string director;
    string actor1;
    string actor2;
    string actor3;
    string duration;
    string language;
    string country;
    string title;
    string year;
    string score;
    string link;
    string linkimage;
    bool loaded= false;
    movie *next;
    movie() {}
    void strChar(char * output, string convert){
        strcpy(output,convert.c_str());
    }

};
#endif //TECFLIX_MOVIE_H
