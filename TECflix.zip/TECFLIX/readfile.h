//
// Created by kevin on 4/10/19.
//

#ifndef TECFLIX_READFILE_H
#define TECFLIX_READFILE_H
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "list.h"

using namespace std;

class readfile {
public:

    list *l1 = new list();



    movie *filme;
    int centpage;
    int cant=12;


    void leer(){
        ifstream archivo;
        string texto;
        archivo.open("/home/kevin/CLionProjects/TECFLIX/movie_metadata.csv", ios::in);

        if(archivo.fail()){
            cerr << "El archivo no se leyó correctamente"<< endl;
        }
        int i = 0;
        int l=0;
        int cont=0;
        while (i<5043){
            getline(archivo, texto);
            vector<string> tmp = split(texto);
            filme= new movie();
            filme->director = tmp[0];
            filme-> actor1= tmp[1];
            filme-> actor2= tmp[2];
            filme-> actor3= tmp[3];
            filme->title = tmp[4];
            filme-> duration= tmp[5];
            filme->language = tmp[6];
            filme->country = tmp[7];
            filme->year = tmp[8];
            filme-> score= tmp[9];
            filme->link = tmp[10];

            l1->insert(filme);
            l++;
            i++;
        }
        l1->printL();
        cout<<l<<endl;
        cout<< "=========================="<< endl;

        archivo.close();
    }

    readfile() {

    }


    vector <std::string> split(const std::string& str){
        std::vector<std::string> resultado;

        std::string::const_iterator itBegin = str.begin();
        std::string::const_iterator itEnd   = str.end();

        int numItems = 1;
        for( std::string::const_iterator it = itBegin; it!=itEnd; ++it )
            numItems += *it==',';

        resultado.reserve(numItems);

        for( std::string::const_iterator it = itBegin; it!=itEnd; ++it )
        {
            if( *it == ',' )
            {
                resultado.push_back(std::string(itBegin,it));
                itBegin = it+1;
            }
        }

        if( itBegin != itEnd )
            resultado.push_back(std::string(itBegin,itEnd));

        return resultado;

    }
    list *getL1() const {
        return l1;
    }
};

#endif // READFILE_H
