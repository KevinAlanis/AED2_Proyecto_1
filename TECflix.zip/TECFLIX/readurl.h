//
// Created by kevin on 4/10/19.
//

#ifndef TECFLIX_READURL_H
#define TECFLIX_READURL_H
#include <stdio.h>
#include <curl/curl.h>
#include "readfile.h"
#include "movie.h"



class readurl{
public:
    string readBuffer;
    readfile *r=new readfile();

    static size_t WriteCallback(void *contents, size_t size, size_t nmemb, void *userp)
    {
        ((std::string*)userp)->append((char*)contents, size * nmemb);
        return size * nmemb;
    }

    void geturl(movie *filme) {
        CURL *curl;
        CURLcode res;
        char link[100];
        filme->strChar(link, filme->link);
        string prueba;

        curl = curl_easy_init();

        if (curl) {
            curl_easy_setopt(curl, CURLOPT_URL, link);
            /* example.com is redirected, so we tell libcurl to follow redirection */
            curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
            curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
            curl_easy_setopt(curl, CURLOPT_WRITEDATA, &prueba);

            /* Perform the request, res will get the return code */
            res = curl_easy_perform(curl);
            /* Check for errors */
            /*
            if(res != CURLE_OK)
                fprintf(stderr, "curl_easy_perform() failed: %s\n",
                        curl_easy_strerror(res));*/

            /* always cleanup */
            curl_easy_cleanup(curl);


            readBuffer = prueba;
            cout << readBuffer << endl;
            cout << "===========*====" << endl;

        }
    }

    void getImage(movie *filme2){
        geturl(filme2);
        int pos = readBuffer.find("Poster\" title=") + 14 ;
        string prueba = readBuffer.substr(pos, 220);

        int pos1 = prueba.find("https");
        int pos2 = prueba.rfind("jpg");

        string link = prueba.substr(pos1, pos2+3-pos1);

        filme2->linkimage = link;
        cout << filme2->linkimage << endl;

    }

    bool downloadimage(movie *film3){
        char url[200];
        getImage(film3);
        film3->strChar(url, film3->linkimage);
        if(!film3->loaded){
            CURL *image;
            CURLcode imgresult;
            string imagename=film3->title;
            imagename.append(".jpg");
            FILE *fp = nullptr;
            image = curl_easy_init();
            if (image)
            {
                // Open file
                fp = fopen(imagename.c_str(), "wb");
                if (fp == NULL)
                    cout << "File cannot be opened";

                curl_easy_setopt(image, CURLOPT_WRITEFUNCTION, NULL);
                curl_easy_setopt(image, CURLOPT_WRITEDATA, fp);
                curl_easy_setopt(image, CURLOPT_URL, url);
                // Grab image
                imgresult = curl_easy_perform(image);
                if (imgresult)
                    cout << "Cannot grab the image!\n";
            }
            // Clean up the resources
            curl_easy_cleanup(image);
            // Close the file
            fclose(fp);
            film3->loaded = true;
        }
    }

    readurl(){
    }

    };
#endif //TECFLIX_READURL_H