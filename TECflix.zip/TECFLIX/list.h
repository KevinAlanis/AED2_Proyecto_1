//
// Created by kevin on 4/10/19.
//

#ifndef TECFLIX_LIST_H
#define TECFLIX_LIST_H
#include <iostream>
#include "movie.h"

using namespace std;
class list {


public:
    movie *head = new movie();
    int len;
public:
    list(){
        len = 0;
        head = nullptr;
    }
    void insert(movie *filme){
        if(head== nullptr){
            head = filme;
            len += 1;
        }
        else if(head != nullptr){
            movie *tmp = head;
            while(tmp->next != nullptr){
                tmp =tmp->next;
            }
            tmp->next = filme;
            len += 1;
        }
    }

    void printL(){
        movie *tmp = head;
        while (tmp != nullptr){
            cout<< tmp->title <<endl;
            tmp = tmp->next;
        }

    }

    void deleFirst(){
        if(head== nullptr){
            cerr << "No hay elementos en la lista" << endl;
        }
        else if(head != nullptr){
            if(len == 1){
                head = nullptr;
                len --;
            }
            else if(len>1){
                movie *tmp1 = head->next;
                head = nullptr;
                head = tmp1;
                len --;
            }

        }
    }

    void deleLast(){
        if(head== nullptr){
            cerr << "No hay elementos en la lista" << endl;
        }
        else if(this->len == 1){
            this->head = nullptr;
            len --;
        }
        else{
            movie *tmp = this->head;
            while(tmp->next->next != nullptr){
                tmp = tmp->next;
            }
            tmp->next= nullptr;
            this->len --;
        }

    }


    movie* index(int pos){
        movie *tmp = head;
        int posi = 0;
        while(posi != pos){
            tmp= tmp->next;
            posi ++;
        }
        return tmp;
    }
    int lenght(){
        return len;
    }
};
#endif //TECFLIX_LIST_H
