#include <iostream>
#include "readfile.h"
#include <gtk/gtk.h>
#include "readurl.h"
#include "readfile.h"

using namespace std;

readfile *r;
readurl *url=new readurl();
string path[11];
string imagepath="";


static void delete_event_cb (GtkWidget *widget, GdkEvent *event, gpointer *data) {
    gtk_main_quit();
}
void closewindow(GtkWidget widget, GdkEventKey *event, gpointer pointer){
    gtk_main_quit();
}

void movieinfo(){
    GdkPixbuf *pix;
    GtkWidget *logo;
    GtkWidget *log;
    GtkWidget *window;
    GtkWidget *layout;
    GtkWidget *back;
    GtkWidget *titlelbl;
    GtkWidget *directorlbl;
    GtkWidget *actor1lbl;
    GtkWidget *actor2lbl;
    GtkWidget *actor3lbl;
    GtkWidget *yearlbl;
    GtkWidget *countrylbl;
    GtkWidget *languagelbl;
    GtkWidget *scorelbl;
    GtkWidget *durationlbl;
    GtkWidget *linklbl;
    GtkWidget *fixed;
    gtk_init(NULL, NULL);
    GtkWidget *background;
    int xsize=700;
    int ysize=500;
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(window), xsize, ysize);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
    gtk_window_set_title(GTK_WINDOW(window),"TECFlix");

    layout = gtk_layout_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER (window), layout);
    gtk_widget_show(layout);
    fixed = gtk_fixed_new();

    background = gtk_image_new_from_file("background.jpg");
    gtk_layout_put(GTK_LAYOUT(layout), background, 0, 0);

    titlelbl=gtk_label_new("");
    directorlbl=gtk_label_new("");
    actor1lbl=gtk_label_new("");
    actor2lbl=gtk_label_new("");
    actor3lbl=gtk_label_new("");
    yearlbl=gtk_label_new("");
    durationlbl=gtk_label_new("");
    scorelbl=gtk_label_new("");
    languagelbl=gtk_label_new("");
    countrylbl=gtk_label_new("");
    linklbl=gtk_label_new("");

    GdkColor color;
    gdk_color_parse ("yellow", &color);
    gtk_widget_modify_fg (titlelbl, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(titlelbl), "Title: ");
    gtk_widget_modify_font (titlelbl,pango_font_description_from_string ("Times New Roman 15"));

    gtk_widget_modify_fg (actor1lbl, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(actor1lbl), "Actor 1: ");
    gtk_widget_modify_font (actor3lbl,pango_font_description_from_string ("Times New Roman 15"));

    gtk_widget_modify_fg (actor2lbl, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(actor2lbl), "Actor 2: ");
    gtk_widget_modify_font (actor2lbl,pango_font_description_from_string ("Times New Roman 15"));

    gtk_widget_modify_fg (actor3lbl, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(actor3lbl), "Actor 3: ");
    gtk_widget_modify_font (actor3lbl,pango_font_description_from_string ("Times New Roman 15"));

    gtk_widget_modify_fg (directorlbl, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(directorlbl), "Director: ");
    gtk_widget_modify_font (directorlbl,pango_font_description_from_string ("Times New Roman 15"));

    gtk_widget_modify_fg (yearlbl, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(yearlbl), "Year: ");
    gtk_widget_modify_font (yearlbl,pango_font_description_from_string ("Times New Roman 15"));

    gtk_widget_modify_fg (durationlbl, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(durationlbl), "Duration: ");
    gtk_widget_modify_font (durationlbl,pango_font_description_from_string ("Times New Roman 15"));

    gtk_widget_modify_fg (scorelbl, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(scorelbl), "Rate: ");
    gtk_widget_modify_font (scorelbl,pango_font_description_from_string ("Times New Roman 15"));

    gtk_widget_modify_fg (countrylbl, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(countrylbl), "Country: ");
    gtk_widget_modify_font (countrylbl,pango_font_description_from_string ("Times New Roman 15"));

    gtk_widget_modify_fg (languagelbl, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(languagelbl), "Language: ");
    gtk_widget_modify_font (languagelbl,pango_font_description_from_string ("Times New Roman 15"));

    gtk_widget_modify_fg (linklbl, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(linklbl), "Trailer: ");
    gtk_widget_modify_font (linklbl,pango_font_description_from_string ("Times New Roman 15"));

    pix=gdk_pixbuf_new_from_file_at_scale("Avatar .jpg",220,300, FALSE, NULL);
    logo=gtk_image_new_from_pixbuf(pix);

    log=gtk_button_new();
    gtk_button_set_image(GTK_BUTTON(log),logo);
    gtk_widget_set_size_request(log,220,300);
    gtk_fixed_put(GTK_FIXED(fixed),log,50,50);

    back=gtk_button_new();
    GdkColor color2;
    gdk_color_parse ("gray", &color);
    gdk_color_parse ("gray", &color2);
    GdkColor color3;
    gdk_color_parse ("black", &color3);
    gtk_widget_modify_fg (back, GTK_STATE_NORMAL, &color3);
    gtk_button_set_label(GTK_BUTTON(back), "BACK");

    gtk_widget_set_size_request(back,50,30);
    gtk_container_add(GTK_CONTAINER(layout), fixed);
    gtk_fixed_put(GTK_FIXED(fixed),titlelbl,370,70);
    gtk_fixed_put(GTK_FIXED(fixed),directorlbl,370,90);
    gtk_fixed_put(GTK_FIXED(fixed),actor1lbl,370,110);
    gtk_fixed_put(GTK_FIXED(fixed),actor2lbl,370,130);
    gtk_fixed_put(GTK_FIXED(fixed),actor3lbl,370,150);
    gtk_fixed_put(GTK_FIXED(fixed),yearlbl,370,170);
    gtk_fixed_put(GTK_FIXED(fixed),durationlbl,370,190);
    gtk_fixed_put(GTK_FIXED(fixed),countrylbl,370,210);
    gtk_fixed_put(GTK_FIXED(fixed),languagelbl,370,230);
    gtk_fixed_put(GTK_FIXED(fixed),linklbl,370,250);
    gtk_fixed_put(GTK_FIXED(fixed),scorelbl,370,270);
    gtk_fixed_put(GTK_FIXED(fixed),back,200,400);

    g_signal_connect(back, "clicked",G_CALLBACK(closewindow), NULL);
    //g_signal_connect (G_OBJECT (window), "delete-event", G_CALLBACK (delete_event_cb), NULL);
    gtk_widget_show_all(window);

    gtk_main();
}

void fourthwindow(GtkWidget widget, GdkEventKey *event, gpointer pointer){

    gtk_init(NULL, NULL);
    GtkWidget *window1;
    GtkWidget *layout1;
    GtkWidget *prev;
    GtkWidget *next;
    GtkWidget *button1;
    GtkWidget *button2;
    GtkWidget *button3;
    GtkWidget *button4;
    GtkWidget *button5;
    GtkWidget *button6;
    GtkWidget *button7;
    GtkWidget *button8;
    GtkWidget *button9;
    GtkWidget *button10;
    GtkWidget *button11;
    GtkWidget *button12;
    GtkWidget *fixed1;

    GtkWidget *background;
    int xsize1=700;
    int ysize1=500;
    window1 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(window1), xsize1, ysize1);
    gtk_window_set_position(GTK_WINDOW(window1), GTK_WIN_POS_CENTER);
    gtk_window_set_title(GTK_WINDOW(window1),"TECFlix");

    layout1 = gtk_layout_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER (window1), layout1);
    gtk_widget_show(layout1);
    fixed1 = gtk_fixed_new();

    background = gtk_image_new_from_file("background.jpg");
    gtk_layout_put(GTK_LAYOUT(layout1), background, 0, 0);


    GdkColor color;
    gdk_color_parse ("yellow", &color);
    GdkColor color3;
    gdk_color_parse ("black", &color3);
    prev=gtk_button_new();
    next=gtk_button_new();
    button1=gtk_button_new();
    button2=gtk_button_new();
    button3=gtk_button_new();
    button4=gtk_button_new();
    button5=gtk_button_new();
    button6=gtk_button_new();
    button7=gtk_button_new();
    button8=gtk_button_new();
    button9=gtk_button_new();
    button10=gtk_button_new();
    button11=gtk_button_new();
    button12=gtk_button_new();

    GtkWidget *movie_image1;
    movie_image1=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image1), "The Golden Compass .jpg");
    GdkPixbuf *pixbuf1 =gtk_image_get_pixbuf(GTK_IMAGE(movie_image1));
    pixbuf1 = gdk_pixbuf_scale_simple(pixbuf1, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image1), pixbuf1);

    GtkWidget *movie_image2;
    movie_image2=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image2), "King Kong .jpg");
    GdkPixbuf *pixbuf2 =gtk_image_get_pixbuf(GTK_IMAGE(movie_image2));
    pixbuf2 = gdk_pixbuf_scale_simple(pixbuf2, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image2), pixbuf2);

    GtkWidget *movie_image3;
    movie_image3=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image3), "Titanic .jpg");
    GdkPixbuf *pixbuf3 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image3));
    pixbuf3 = gdk_pixbuf_scale_simple(pixbuf3, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image3), pixbuf3);

    GtkWidget *movie_image4;
    movie_image4=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image4), "Captain America: Civil War .jpg");
    GdkPixbuf *pixbuf4 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image4));
    pixbuf4= gdk_pixbuf_scale_simple(pixbuf4, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image4), pixbuf4);

    GtkWidget *movie_image5;
    movie_image5=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image5), "Battleship .jpg");
    GdkPixbuf *pixbuf5 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image5));
    pixbuf5 = gdk_pixbuf_scale_simple(pixbuf5, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image5), pixbuf5);

    GtkWidget *movie_image6;
    movie_image6=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image6), "Jurassic World .jpg");
    GdkPixbuf *pixbuf6 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image6));
    pixbuf6 = gdk_pixbuf_scale_simple(pixbuf6, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image6), pixbuf6);

    GtkWidget *movie_image7;
    movie_image7=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image7), "Skyfall .jpg");
    GdkPixbuf *pixbuf7 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image7));
    pixbuf7 = gdk_pixbuf_scale_simple(pixbuf7, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image7), pixbuf7);

    GtkWidget *movie_image8;
    movie_image8=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image8), "Spider-Man 2 .jpg");
    GdkPixbuf *pixbuf8 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image8));
    pixbuf8 = gdk_pixbuf_scale_simple(pixbuf8, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image8), pixbuf8);

    GtkWidget *movie_image9;
    movie_image9=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image9), "Iron Man 3 .jpg");
    GdkPixbuf *pixbuf9 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image9));
    pixbuf9 = gdk_pixbuf_scale_simple(pixbuf9, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image9), pixbuf9);

    GtkWidget *movie_image10;
    movie_image10=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image10), "Alice in Wonderland .jpg");
    GdkPixbuf *pixbuf10 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image10));
    pixbuf10 = gdk_pixbuf_scale_simple(pixbuf10, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image10), pixbuf10);

    GtkWidget *movie_image11;
    movie_image11=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image11), "X-Men: The Last Stand .jpg");
    GdkPixbuf *pixbuf11 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image11));
    pixbuf11 = gdk_pixbuf_scale_simple(pixbuf11, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image11), pixbuf11);

    GtkWidget *movie_image12;
    movie_image12=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image12), "Monsters University .jpg");
    GdkPixbuf *pixbuf12 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image12));
    pixbuf12 = gdk_pixbuf_scale_simple(pixbuf12, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image12), pixbuf12);



    gtk_button_set_image(GTK_BUTTON(button1), movie_image1);
    gtk_widget_set_size_request(button1,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button1,100,25);

    gtk_button_set_image(GTK_BUTTON(button2), movie_image2);
    gtk_widget_set_size_request(button2,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button2,240,25);

    gtk_button_set_image(GTK_BUTTON(button3), movie_image3);
    gtk_widget_set_size_request(button3,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button3,380,25);

    gtk_button_set_image(GTK_BUTTON(button4), movie_image4);
    gtk_widget_set_size_request(button4,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button4,520,25);

    gtk_button_set_image(GTK_BUTTON(button5), movie_image5);
    gtk_widget_set_size_request(button5,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button5,100,175);

    gtk_button_set_image(GTK_BUTTON(button6), movie_image6);
    gtk_widget_set_size_request(button6,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button6,240,175);

    gtk_button_set_image(GTK_BUTTON(button7), movie_image7);
    gtk_widget_set_size_request(button7,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button7,380,175);

    gtk_button_set_image(GTK_BUTTON(button8), movie_image8);
    gtk_widget_set_size_request(button8,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button8,520,175);

    gtk_button_set_image(GTK_BUTTON(button9), movie_image9);
    gtk_widget_set_size_request(button9,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button9,100,320);

    gtk_button_set_image(GTK_BUTTON(button10), movie_image10);
    gtk_widget_set_size_request(button10,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button10,240,320);

    gtk_button_set_image(GTK_BUTTON(button11), movie_image11);
    gtk_widget_set_size_request(button11,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button11,380,320);

    gtk_button_set_image(GTK_BUTTON(button12), movie_image12);
    gtk_widget_set_size_request(button12,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button12,520,320);


    GdkColor color2;
    gdk_color_parse ("gray", &color);
    gdk_color_parse ("gray", &color2);
    gtk_widget_modify_fg (prev, GTK_STATE_NORMAL, &color3);
    gtk_widget_modify_fg (next, GTK_STATE_NORMAL, &color3);
    gtk_button_set_label(GTK_BUTTON(prev), "PREV");
    gtk_button_set_label(GTK_BUTTON(next), "NEXT");

    gtk_widget_set_size_request(prev,65,40);
    gtk_widget_set_size_request(next,65,40);
    gtk_container_add(GTK_CONTAINER(layout1), fixed1);
    gtk_fixed_put(GTK_FIXED(fixed1),prev,50,450);
    gtk_fixed_put(GTK_FIXED(fixed1),next,600,450);

    //g_signal_connect(prev, "clicked",G_CALLBACK(refreshwindow), NULL);
    //g_signal_connect(next, "clicked",G_CALLBACK(thirdwindow), NULL);
    g_signal_connect (G_OBJECT (window1), "delete-event", G_CALLBACK (delete_event_cb), NULL);
    gtk_widget_show_all(window1);
}


void thirdwindow(GtkWidget widget, GdkEventKey *event, gpointer pointer){

    gtk_init(NULL, NULL);
    GtkWidget *window1;
    GtkWidget *layout1;
    GtkWidget *prev;
    GtkWidget *next;
    GtkWidget *button1;
    GtkWidget *button2;
    GtkWidget *button3;
    GtkWidget *button4;
    GtkWidget *button5;
    GtkWidget *button6;
    GtkWidget *button7;
    GtkWidget *button8;
    GtkWidget *button9;
    GtkWidget *button10;
    GtkWidget *button11;
    GtkWidget *button12;
    GtkWidget *fixed1;

    GtkWidget *background;
    int xsize1=700;
    int ysize1=500;
    window1 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(window1), xsize1, ysize1);
    gtk_window_set_position(GTK_WINDOW(window1), GTK_WIN_POS_CENTER);
    gtk_window_set_title(GTK_WINDOW(window1),"TECFlix");

    layout1 = gtk_layout_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER (window1), layout1);
    gtk_widget_show(layout1);
    fixed1 = gtk_fixed_new();

    background = gtk_image_new_from_file("background.jpg");
    gtk_layout_put(GTK_LAYOUT(layout1), background, 0, 0);


    GdkColor color;
    gdk_color_parse ("yellow", &color);
    GdkColor color3;
    gdk_color_parse ("black", &color3);
    prev=gtk_button_new();
    next=gtk_button_new();
    button1=gtk_button_new();
    button2=gtk_button_new();
    button3=gtk_button_new();
    button4=gtk_button_new();
    button5=gtk_button_new();
    button6=gtk_button_new();
    button7=gtk_button_new();
    button8=gtk_button_new();
    button9=gtk_button_new();
    button10=gtk_button_new();
    button11=gtk_button_new();
    button12=gtk_button_new();

    GtkWidget *movie_image1;
    movie_image1=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image1), "Quantum of Solace .jpg");
    GdkPixbuf *pixbuf1 =gtk_image_get_pixbuf(GTK_IMAGE(movie_image1));
    pixbuf1 = gdk_pixbuf_scale_simple(pixbuf1, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image1), pixbuf1);

    GtkWidget *movie_image2;
    movie_image2=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image2), "Pirates of the Caribbean: Dead Man's Chest .jpg");
    GdkPixbuf *pixbuf2 =gtk_image_get_pixbuf(GTK_IMAGE(movie_image2));
    pixbuf2 = gdk_pixbuf_scale_simple(pixbuf2, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image2), pixbuf2);

    GtkWidget *movie_image3;
    movie_image3=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image3), "The Lone Ranger .jpg");
    GdkPixbuf *pixbuf3 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image3));
    pixbuf3 = gdk_pixbuf_scale_simple(pixbuf3, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image3), pixbuf3);

    GtkWidget *movie_image4;
    movie_image4=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image4), "Man of Steel .jpg");
    GdkPixbuf *pixbuf4 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image4));
    pixbuf4= gdk_pixbuf_scale_simple(pixbuf4, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image4), pixbuf4);

    GtkWidget *movie_image5;
    movie_image5=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image5), "The Chronicles of Narnia: Prince Caspian .jpg");
    GdkPixbuf *pixbuf5 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image5));
    pixbuf5 = gdk_pixbuf_scale_simple(pixbuf5, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image5), pixbuf5);

    GtkWidget *movie_image6;
    movie_image6=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image6), "The Avengers .jpg");
    GdkPixbuf *pixbuf6 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image6));
    pixbuf6 = gdk_pixbuf_scale_simple(pixbuf6, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image6), pixbuf6);

    GtkWidget *movie_image7;
    movie_image7=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image7), "Pirates of the Caribbean: On Stranger Tides .jpg");
    GdkPixbuf *pixbuf7 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image7));
    pixbuf7 = gdk_pixbuf_scale_simple(pixbuf7, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image7), pixbuf7);

    GtkWidget *movie_image8;
    movie_image8=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image8), "Men in Black 3 .jpg");
    GdkPixbuf *pixbuf8 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image8));
    pixbuf8 = gdk_pixbuf_scale_simple(pixbuf8, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image8), pixbuf8);

    GtkWidget *movie_image9;
    movie_image9=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image9), "The Hobbit: The Battle of the Five Armies .jpg");
    GdkPixbuf *pixbuf9 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image9));
    pixbuf9 = gdk_pixbuf_scale_simple(pixbuf9, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image9), pixbuf9);

    GtkWidget *movie_image10;
    movie_image10=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image10), "The Amazing Spider-Man .jpg");
    GdkPixbuf *pixbuf10 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image10));
    pixbuf10 = gdk_pixbuf_scale_simple(pixbuf10, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image10), pixbuf10);

    GtkWidget *movie_image11;
    movie_image11=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image11), "Robin Hood .jpg");
    GdkPixbuf *pixbuf11 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image11));
    pixbuf11 = gdk_pixbuf_scale_simple(pixbuf11, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image11), pixbuf11);

    GtkWidget *movie_image12;
    movie_image12=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image12), "The Hobbit: The Desolation of Smaug .jpg");
    GdkPixbuf *pixbuf12 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image12));
    pixbuf12 = gdk_pixbuf_scale_simple(pixbuf12, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image12), pixbuf12);



    gtk_button_set_image(GTK_BUTTON(button1), movie_image1);
    gtk_widget_set_size_request(button1,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button1,100,25);

    gtk_button_set_image(GTK_BUTTON(button2), movie_image2);
    gtk_widget_set_size_request(button2,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button2,240,25);

    gtk_button_set_image(GTK_BUTTON(button3), movie_image3);
    gtk_widget_set_size_request(button3,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button3,380,25);

    gtk_button_set_image(GTK_BUTTON(button4), movie_image4);
    gtk_widget_set_size_request(button4,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button4,520,25);

    gtk_button_set_image(GTK_BUTTON(button5), movie_image5);
    gtk_widget_set_size_request(button5,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button5,100,175);

    gtk_button_set_image(GTK_BUTTON(button6), movie_image6);
    gtk_widget_set_size_request(button6,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button6,240,175);

    gtk_button_set_image(GTK_BUTTON(button7), movie_image7);
    gtk_widget_set_size_request(button7,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button7,380,175);

    gtk_button_set_image(GTK_BUTTON(button8), movie_image8);
    gtk_widget_set_size_request(button8,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button8,520,175);

    gtk_button_set_image(GTK_BUTTON(button9), movie_image9);
    gtk_widget_set_size_request(button9,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button9,100,320);

    gtk_button_set_image(GTK_BUTTON(button10), movie_image10);
    gtk_widget_set_size_request(button10,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button10,240,320);

    gtk_button_set_image(GTK_BUTTON(button11), movie_image11);
    gtk_widget_set_size_request(button11,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button11,380,320);

    gtk_button_set_image(GTK_BUTTON(button12), movie_image12);
    gtk_widget_set_size_request(button12,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button12,520,320);


    GdkColor color2;
    gdk_color_parse ("gray", &color);
    gdk_color_parse ("gray", &color2);
    gtk_widget_modify_fg (prev, GTK_STATE_NORMAL, &color3);
    gtk_widget_modify_fg (next, GTK_STATE_NORMAL, &color3);
    gtk_button_set_label(GTK_BUTTON(prev), "PREV");
    gtk_button_set_label(GTK_BUTTON(next), "NEXT");

    gtk_widget_set_size_request(prev,65,40);
    gtk_widget_set_size_request(next,65,40);
    gtk_container_add(GTK_CONTAINER(layout1), fixed1);
    gtk_fixed_put(GTK_FIXED(fixed1),prev,50,450);
    gtk_fixed_put(GTK_FIXED(fixed1),next,600,450);

    //g_signal_connect(prev, "clicked",G_CALLBACK(firstwindow), NULL);
    g_signal_connect(next, "clicked",G_CALLBACK(fourthwindow), NULL);
    g_signal_connect (G_OBJECT (window1), "delete-event", G_CALLBACK (delete_event_cb), NULL);
    gtk_widget_show_all(window1);
}





void loadpages(int centpage){
    if(centpage==0) {
        for (int i = 0; i <= 2; i++) {
            url->downloadimage(r->l1->index(i));
            imagepath.append(r->l1->index(i)->title);
            imagepath.append(".jpg");
            path[i] = imagepath.c_str();

        }


        for (int c = 12; c < 24; c++) {
            url->downloadimage(r->l1->index(c));
        }
    }else {
        for (int d = 24; d < 36; d++) {
            url->downloadimage(r->l1->index(d));
        }
    }

}

void secondwindow(GtkWidget widget, GdkEventKey *event, gpointer pointer){
    url->geturl(r->l1->index(0));
    url->getImage(r->l1->index(0));
    loadpages(1);

    gtk_init(NULL, NULL);
    GtkWidget *window1;
    GtkWidget *layout1;
    GtkWidget *prev;
    GtkWidget *next;
    GtkWidget *button1;
    GtkWidget *button2;
    GtkWidget *button3;
    GtkWidget *button4;
    GtkWidget *button5;
    GtkWidget *button6;
    GtkWidget *button7;
    GtkWidget *button8;
    GtkWidget *button9;
    GtkWidget *button10;
    GtkWidget *button11;
    GtkWidget *button12;
    GtkWidget *fixed1;

    GtkWidget *background;
    int xsize1=700;
    int ysize1=500;
    window1 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(window1), xsize1, ysize1);
    gtk_window_set_position(GTK_WINDOW(window1), GTK_WIN_POS_CENTER);
    gtk_window_set_title(GTK_WINDOW(window1),"TECFlix");

    layout1 = gtk_layout_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER (window1), layout1);
    gtk_widget_show(layout1);
    fixed1 = gtk_fixed_new();

    background = gtk_image_new_from_file("background.jpg");
    gtk_layout_put(GTK_LAYOUT(layout1), background, 0, 0);


    GdkColor color;
    gdk_color_parse ("yellow", &color);
    GdkColor color3;
    gdk_color_parse ("black", &color3);
    prev=gtk_button_new();
    next=gtk_button_new();
    button1=gtk_button_new();
    button2=gtk_button_new();
    button3=gtk_button_new();
    button4=gtk_button_new();
    button5=gtk_button_new();
    button6=gtk_button_new();
    button7=gtk_button_new();
    button8=gtk_button_new();
    button9=gtk_button_new();
    button10=gtk_button_new();
    button11=gtk_button_new();
    button12=gtk_button_new();

    GtkWidget *movie_image1;
    movie_image1=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image1), "Avatar .jpg");
    GdkPixbuf *pixbuf1 =gtk_image_get_pixbuf(GTK_IMAGE(movie_image1));
    pixbuf1 = gdk_pixbuf_scale_simple(pixbuf1, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image1), pixbuf1);

    GtkWidget *movie_image2;
    movie_image2=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image2), "Pirates of the Caribbean: At World's End .jpg");
    GdkPixbuf *pixbuf2 =gtk_image_get_pixbuf(GTK_IMAGE(movie_image2));
    pixbuf2 = gdk_pixbuf_scale_simple(pixbuf2, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image2), pixbuf2);

    GtkWidget *movie_image3;
    movie_image3=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image3), "Spectre .jpg");
    GdkPixbuf *pixbuf3 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image3));
    pixbuf3 = gdk_pixbuf_scale_simple(pixbuf3, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image3), pixbuf3);

    GtkWidget *movie_image4;
    movie_image4=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image4), "The Dark Knight Rises .jpg");
    GdkPixbuf *pixbuf4 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image4));
    pixbuf4= gdk_pixbuf_scale_simple(pixbuf4, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image4), pixbuf4);

    GtkWidget *movie_image5;
    movie_image5=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image5), "Star Wars: Episode VII - The Force Awakens .jpg");
    GdkPixbuf *pixbuf5 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image5));
    pixbuf5 = gdk_pixbuf_scale_simple(pixbuf5, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image5), pixbuf5);

    GtkWidget *movie_image6;
    movie_image6=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image6), "John Carter .jpg");
    GdkPixbuf *pixbuf6 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image6));
    pixbuf6 = gdk_pixbuf_scale_simple(pixbuf6, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image6), pixbuf6);

    GtkWidget *movie_image7;
    movie_image7=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image7), "Spider-Man 3 .jpg");
    GdkPixbuf *pixbuf7 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image7));
    pixbuf7 = gdk_pixbuf_scale_simple(pixbuf7, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image7), pixbuf7);

    GtkWidget *movie_image8;
    movie_image8=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image8), "Tangled .jpg");
    GdkPixbuf *pixbuf8 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image8));
    pixbuf8 = gdk_pixbuf_scale_simple(pixbuf8, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image8), pixbuf8);

    GtkWidget *movie_image9;
    movie_image9=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image9), "Avengers: Age of Ultron .jpg");
    GdkPixbuf *pixbuf9 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image9));
    pixbuf9 = gdk_pixbuf_scale_simple(pixbuf9, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image9), pixbuf9);

    GtkWidget *movie_image10;
    movie_image10=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image10), "Harry Potter and the Half-Blood Prince .jpg");
    GdkPixbuf *pixbuf10 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image10));
    pixbuf10 = gdk_pixbuf_scale_simple(pixbuf10, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image10), pixbuf10);

    GtkWidget *movie_image11;
    movie_image11=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image11), "Batman v Superman: Dawn of Justice .jpg");
    GdkPixbuf *pixbuf11 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image11));
    pixbuf11 = gdk_pixbuf_scale_simple(pixbuf11, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image11), pixbuf11);

    GtkWidget *movie_image12;
    movie_image12=gtk_image_new();
    gtk_image_set_from_file(GTK_IMAGE(movie_image12), "Superman Returns .jpg");
    GdkPixbuf *pixbuf12 =	gtk_image_get_pixbuf(GTK_IMAGE(movie_image12));
    pixbuf12 = gdk_pixbuf_scale_simple(pixbuf12, 100,100, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(movie_image12), pixbuf12);



    gtk_button_set_image(GTK_BUTTON(button1), movie_image1);
    gtk_widget_set_size_request(button1,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button1,100,25);

    gtk_button_set_image(GTK_BUTTON(button2), movie_image2);
    gtk_widget_set_size_request(button2,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button2,240,25);

    gtk_button_set_image(GTK_BUTTON(button3), movie_image3);
    gtk_widget_set_size_request(button3,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button3,380,25);

    gtk_button_set_image(GTK_BUTTON(button4), movie_image4);
    gtk_widget_set_size_request(button4,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button4,520,25);

    gtk_button_set_image(GTK_BUTTON(button5), movie_image5);
    gtk_widget_set_size_request(button5,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button5,100,175);

    gtk_button_set_image(GTK_BUTTON(button6), movie_image6);
    gtk_widget_set_size_request(button6,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button6,240,175);

    gtk_button_set_image(GTK_BUTTON(button7), movie_image7);
    gtk_widget_set_size_request(button7,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button7,380,175);

    gtk_button_set_image(GTK_BUTTON(button8), movie_image8);
    gtk_widget_set_size_request(button8,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button8,520,175);

    gtk_button_set_image(GTK_BUTTON(button9), movie_image9);
    gtk_widget_set_size_request(button9,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button9,100,320);

    gtk_button_set_image(GTK_BUTTON(button10), movie_image10);
    gtk_widget_set_size_request(button10,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button10,240,320);

    gtk_button_set_image(GTK_BUTTON(button11), movie_image11);
    gtk_widget_set_size_request(button11,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button11,380,320);

    gtk_button_set_image(GTK_BUTTON(button12), movie_image12);
    gtk_widget_set_size_request(button12,100,100);
    gtk_fixed_put(GTK_FIXED(fixed1),button12,520,320);


    GdkColor color2;
    gdk_color_parse ("gray", &color);
    gdk_color_parse ("gray", &color2);
    gtk_widget_modify_fg (prev, GTK_STATE_NORMAL, &color3);
    gtk_widget_modify_fg (next, GTK_STATE_NORMAL, &color3);
    gtk_button_set_label(GTK_BUTTON(prev), "PREV");
    gtk_button_set_label(GTK_BUTTON(next), "NEXT");

    gtk_widget_set_size_request(prev,65,40);
    gtk_widget_set_size_request(next,65,40);
    gtk_container_add(GTK_CONTAINER(layout1), fixed1);
    gtk_fixed_put(GTK_FIXED(fixed1),prev,50,450);
    gtk_fixed_put(GTK_FIXED(fixed1),next,600,450);

    //g_signal_connect(prev, "clicked",G_CALLBACK(firstwindow), NULL);
    g_signal_connect(next, "clicked",G_CALLBACK(thirdwindow), NULL);
    g_signal_connect (G_OBJECT (window1), "delete-event", G_CALLBACK (delete_event_cb), NULL);
    gtk_widget_show_all(window1);
}





int main(int argc, char*argv[]) {
    r=new readfile();
    r->leer();

    GdkPixbuf *pix;
    GtkWidget *logo;
    GtkWidget *log;
    GtkWidget *window;
    GtkWidget *layout;
    GtkWidget *exit;
    GtkWidget *start;
    GtkWidget *tecflixlbl;
    GtkWidget *fixed;
    gtk_init(&argc,&argv);
    GtkWidget *background;
    int xsize=700;
    int ysize=500;
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(window), xsize, ysize);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
    gtk_window_set_title(GTK_WINDOW(window),"TECFlix");

    layout = gtk_layout_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER (window), layout);
    gtk_widget_show(layout);
    fixed = gtk_fixed_new();

    background = gtk_image_new_from_file("background.jpg");
    gtk_layout_put(GTK_LAYOUT(layout), background, 0, 0);

    tecflixlbl=gtk_label_new("");

    GdkColor color;
    gdk_color_parse ("yellow", &color);
    gtk_widget_modify_fg (tecflixlbl, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(tecflixlbl), "TECFLIX");
    gtk_widget_modify_font (tecflixlbl,pango_font_description_from_string ("Times New Roman 20"));

    pix=gdk_pixbuf_new_from_file_at_scale("logo.png",180,200, FALSE, NULL);
    logo=gtk_image_new_from_pixbuf(pix);

    log=gtk_button_new();
    gtk_button_set_image(GTK_BUTTON(log),logo);
    gtk_widget_set_size_request(log,180,200);
    gtk_fixed_put(GTK_FIXED(fixed),log,260,125);

    exit=gtk_button_new();
    start=gtk_button_new();
    GdkColor color2;
    gdk_color_parse ("gray", &color);
    gdk_color_parse ("gray", &color2);
    GdkColor color3;
    gdk_color_parse ("black", &color3);
    gtk_widget_modify_fg (exit, GTK_STATE_NORMAL, &color3);
    gtk_widget_modify_fg (start, GTK_STATE_NORMAL, &color3);
    gtk_button_set_label(GTK_BUTTON(exit), "EXIT");
    gtk_button_set_label(GTK_BUTTON(start), "START");

    gtk_widget_set_size_request(exit,50,30);
    gtk_widget_set_size_request(start,50,30);
    gtk_container_add(GTK_CONTAINER(layout), fixed);
    gtk_fixed_put(GTK_FIXED(fixed),tecflixlbl,290,60);
    gtk_fixed_put(GTK_FIXED(fixed),exit,200,400);
    gtk_fixed_put(GTK_FIXED(fixed),start,450,400);;

    g_signal_connect(exit, "clicked",G_CALLBACK(closewindow), NULL);
    g_signal_connect(start, "clicked",G_CALLBACK(secondwindow), NULL);
    g_signal_connect (G_OBJECT (window), "delete-event", G_CALLBACK (delete_event_cb), NULL);
    gtk_widget_show_all(window);

    gtk_main();
}